import type { NextApiRequest, NextApiResponse } from "next";
import { createHash, randomInt } from "crypto";
import { createClient } from "@supabase/supabase-js";
import { sendOtpEmail, maskEmail } from '@/lib/mail';
import { mkdir, writeFile } from 'fs/promises';

function hash(code: string) {
  return createHash("sha256").update(code).digest("hex");
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  // Normalize email (match verify-otp.ts normalization)
  const ownerEmail = (process.env.OWNER_EMAIL || "").trim().toLowerCase();
  const requestEmail = (req.body?.email || "").toString().trim().toLowerCase();
  const ownerUUID = process.env.OWNER_UUID;

  // Owner-only system: don't leak owner presence
  if (!requestEmail || !ownerEmail || requestEmail !== ownerEmail) {
    return res.status(200).json({ ok: true });
  }

  // Rate limiting (very light): hash of ip+ua per minute key
  // NOTE: implement stronger rate-limits via reverse proxy if needed
  const code = String(randomInt(0, 1000000)).padStart(6, "0");
  const codeHash = hash(code);
  const expires = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  // DEV MODE: Skip DB and just log the code
  if (process.env.NODE_ENV === "development") {
    console.log(`[OTP][DEV] Code for ${requestEmail}: ${code} (valid for 10 min)`);
    return res.status(200).json({ ok: true, code });
  }

  // *** USE SERVICE ROLE for inserts (bypasses RLS) ***
  const supabaseAdmin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  const ipua = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "") + "|" + (req.headers["user-agent"] || "");
  const { data, error } = await supabaseAdmin
    .from("auth_otp")
    .insert({
      user_id: ownerUUID,
      code_hash: codeHash,
      expires_at: expires,
      ip_fingerprint: hash(ipua)
    })
    .select()
    .single();

  // Production-safe error handling
  if (error) {
    console.error("[OTP] DB insert failed:", error);
    const isProduction = process.env.NODE_ENV === "production";
    return res.status(isProduction ? 200 : 500).json(
      isProduction
        ? { ok: true }
        : { ok: false, error: "OTP_DB_INSERT_FAILED" }
    );
  }

  // === SEND EMAIL & WRITE RECEIPT BEFORE RETURN ===
  try {
    const info = await sendOtpEmail(requestEmail, code);  // await real send
    try {
      const dir = '/var/www/chatbot-ui-staging/ops/artifacts/login-otp-receipts';
      await mkdir(dir, { recursive: true, mode: 0o700 });
      const ts = new Date().toISOString().replace(/[:.]/g,'');
      const rec = {
        step: 'otp.send',
        ts: new Date().toISOString(),
        to_masked: maskEmail(requestEmail),
        messageId: info?.messageId || null,
        accepted: info?.accepted || [],
        rejected: info?.rejected || [],
      };
      await writeFile(`${dir}/OTP-${ts}.json`, JSON.stringify(rec,null,2), { mode: 0o600 });
    } catch {}
    
    // Dev mode fallback
    if (process.env.AUTH_MODE === "dev") return res.status(200).json({ ok: true, code });
    
    return res.status(200).json({ ok: true });
  } catch (mailError) {
    // Log error but don't leak details
    console.error('[OTP] Mail send failed:', mailError);
    return res.status(200).json({ ok: true }); // Still return ok to avoid enumeration
  }
}
