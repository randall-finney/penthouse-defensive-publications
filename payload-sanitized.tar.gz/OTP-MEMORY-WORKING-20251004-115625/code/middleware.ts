import { NextResponse, NextRequest } from "next/server";
const OWNER_WS = process.env.OWNER_WORKSPACE_ID || "";

function hasCookie(name: string, req: NextRequest) {
  const c = req.headers.get("cookie") || "";
  return new RegExp("(?:^|; )"+name+"=").test(c);
}

export function middleware(req: NextRequest) {
  const url = new URL(req.url);
  const path = url.pathname;

  const hasOwner = hasCookie("owner_session", req);
  const hasSb    = hasCookie("sb-access-token", req) || hasCookie("sb-refresh-token", req);

  // Always allow auth APIs and the login flow to pass through (OTP must be reachable)
  if (path.startsWith("/api/auth/") || path.startsWith("/en/login")) {
    return NextResponse.next();
  }

  // Root splash: direct based on owner cookie (legacy behavior)
  if (path === "/") {
    return hasOwner
      ? NextResponse.redirect(new URL(`/en/${OWNER_WS}/chat`, url))
      : NextResponse.redirect(new URL("/en/login", url));
  }

  // Protected app routes: if neither owner cookie nor Supabase session, send to login
  if (path.startsWith("/en/") && !hasOwner && !hasSb) {
    return NextResponse.redirect(new URL("/en/login", url));
  }

  return NextResponse.next();
}

export const config = { matcher: ["/", "/en/:path*", "/api/auth/:path*"] };
