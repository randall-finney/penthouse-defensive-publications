import type { NextApiRequest, NextApiResponse } from "next";
const hasPending=(req:any)=>{const c=req.headers['cookie']||'';return /pending_login=/.test(String(c));}; 
import crypto from "node:crypto";
import { createClient } from "@supabase/supabase-js";
import { createServerClient } from "@supabase/ssr";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const OWNER_UUID = (process.env.OWNER_UUID || "").trim();
const OWNER_WORKSPACE_ID = (process.env.OWNER_WORKSPACE_ID || "").trim();
const OWNER_EMAIL = (process.env.OWNER_EMAIL || "").trim().toLowerCase();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if(!hasPending(req)) { return res.status(403).json({ ok:false }); }
  try {
    if (req.method !== "POST") return res.status(405).end();

    const { email, code } = req.body || {};
    const normEmail = String(email || "").trim().toLowerCase();
    const normCode = String(code || "").trim();

    if (!normEmail || !/^\d{6}$/.test(normCode)) {
      return res.status(400).json({ ok: false, error: "invalid_input" });
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
      auth: { autoRefreshToken: false, persistSession: false }
    });

    // Fetch latest un-used, un-expired OTP for owner
    const { data: rows, error} = await supabase
      .from("auth_otp")
      .select("id, code_hash, expires_at, used_at")
      .eq("user_id", OWNER_UUID)
      .is("used_at", null)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1);

    if (error || !rows || rows.length === 0) {
      return res.status(401).json({ ok: false, error: "no_active_otp" });
    }

    const row = rows[0];

    // Match hash scheme from request-otp.ts (no nonce)
    const hash = crypto.createHash("sha256").update(normCode).digest("hex");

    if (hash !== row.code_hash) {
      return res.status(401).json({ ok: false, error: "bad_code" });
    }

    // Mark OTP as used (prevent replay)
    await supabaseAdmin.from("auth_otp").update({ used_at: new Date().toISOString() }).eq("id", row.id);

    // Ensure the owner user exists in Supabase Auth
    const { data: userData } = await supabaseAdmin.auth.admin.getUserById(OWNER_UUID);

    if (!userData?.user) {
      // User doesn't exist, create them with a random password
      const randomPassword = crypto.randomBytes(32).toString('hex');
      const { data: newUserData, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email: OWNER_EMAIL,
        password: randomPassword,
        email_confirm: true,
        user_metadata: { role: 'owner' }
      });

      if (createError || !newUserData?.user) {
        console.error("Failed to create user:", createError);
        return res.status(500).json({ ok: false, error: "user_creation_failed" });
      }
    }

    // Generate a passwordless sign-in link
    const { data: linkData, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
      type: 'magiclink',
      email: OWNER_EMAIL
    });

    if (linkError || !linkData) {
      console.error("Failed to generate link:", linkError);
      return res.status(500).json({ ok: false, error: "link_generation_failed" });
    }

    // Create SSR client to handle session cookies
    const cookiesToSet: string[] = [];

    const supabaseSSR = createServerClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      cookies: {
        get(name: string) {
          return req.cookies[name];
        },
        set(name: string, value: string, options: any) {
          const parts = [
            `${name}=${value}`,
            `Path=${options.path || '/'}`,
            options.maxAge ? `Max-Age=${options.maxAge}` : '',
            options.httpOnly ? 'HttpOnly' : '',
            options.secure ? 'Secure' : '',
            options.sameSite ? `SameSite=${options.sameSite}` : ''
          ].filter(Boolean);
          cookiesToSet.push(parts.join('; '));
        },
        remove(name: string, options: any) {
          cookiesToSet.push(`${name}=; Path=${options.path || '/'}; Max-Age=0`);
        }
      }
    });

    // Exchange the hashed token for a session using verifyOtp
    const { data: sessionData, error: sessionError } = await supabaseSSR.auth.verifyOtp({
      type: 'email',
      token_hash: linkData.properties.hashed_token,
      options: {
        redirectTo: `${SUPABASE_URL}/en/${OWNER_WORKSPACE_ID}/chat`
      }
    });

    if (sessionError || !sessionData?.session) {
      console.error("Failed to verify OTP:", sessionError);
      return res.status(500).json({ ok: false, error: "session_creation_failed", details: sessionError?.message });
    }

    // Add owner_session cookie
    const maxAge = 60 * 60 * 24; // 24h
    const domain = "staging.alaricthatcherbooks.com";
    cookiesToSet.push(`owner_session=${OWNER_UUID}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax; Domain=${domain}`);

    // Set all cookies
    // clear pending_login cookie
    const clearPending = "pending_login=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax";
    cookiesToSet.push(clearPending);
    res.setHeader("Set-Cookie", cookiesToSet);

    return res.status(200).json({
      ok: true,
      redirect: `/en/${OWNER_WORKSPACE_ID}/chat`
    });
  } catch (e) {
    console.error("VERIFY_OTP_ERROR", e);
    return res.status(500).json({ ok: false, error: "server_error" });
  }
}
