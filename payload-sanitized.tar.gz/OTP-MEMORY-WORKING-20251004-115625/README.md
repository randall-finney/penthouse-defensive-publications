# OTP MEMORY WORKING CONDITION

**Status**: ✅ FULLY OPERATIONAL
**Date**: $(TZ=America/Chicago date)
**Environment**: Staging (staging.alaricthatcherbooks.com)

## What Works
- ✅ OTP login flow (request-otp → verify-otp)
- ✅ Supabase session creation (sb-* cookies set correctly)
- ✅ RLS policy allows owner workspace access
- ✅ Chat interface loads
- ✅ All chats accessible
- ✅ Memory retrieval working

## Key Components

### 1. Middleware (middleware.ts)
- Allows `/en/login` and `/api/auth/*` to pass through
- Checks for both `owner_session` AND `sb-*` cookies
- Redirects unauthenticated users to login

### 2. OTP Request (pages/api/auth/request-otp.ts)
- Uses **service role** client for auth_otp inserts
- Bypasses RLS (no anon insert policy needed)
- Stores: user_id, code_hash, expires_at, ip_fingerprint
- Sends email via SendGrid

### 3. OTP Verify (pages/api/auth/verify-otp.ts)
- Queries auth_otp by user_id (not email)
- Creates Supabase session via SSR client
- Sets sb-access-token, sb-refresh-token, owner_session cookies
- Marks OTP as used

### 4. RLS Policy (workspaces table)
```sql
create policy owner_can_read_own_workspace
  on public.workspaces
  for select
  using (user_id = auth.uid());
```

### 5. Database State
- Workspace c1884958-2717-486f-b865-6db90c210de8 exists
- user_id: 44e653b6-178d-4bfc-b003-2c275d0a51a8
- sharing: private
- RLS enabled on workspaces table

## Critical Success Factors
1. Service role used for auth_otp inserts (not anon key)
2. No email column in auth_otp (user_id keyed)
3. Middleware allows login flow to complete
4. verify-otp creates proper Supabase session
5. RLS policy matches auth.uid() to workspace.user_id

## Testing Checklist
- [ ] Fresh incognito → /en/login → 200
- [ ] Request OTP → email received
- [ ] Submit code → redirects to chat
- [ ] Cookies: sb-access-token, sb-refresh-token, owner_session
- [ ] Workspace query → 200 OK
- [ ] Chats load
- [ ] Memories accessible

## Rollback Info
- Git commit: $(git log -1 --oneline)
- BUILD_ID: $(cat .next/BUILD_ID 2>/dev/null || echo "N/A")
- PM2 restarts: $(pm2 describe penthouse-staging 2>/dev/null | grep "restarts" || echo "N/A")
