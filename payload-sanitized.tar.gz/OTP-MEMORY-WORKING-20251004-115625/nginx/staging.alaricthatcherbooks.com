server {
  server_name staging.alaricthatcherbooks.com;
    client_max_body_size 10m;

    # Redirect bare UUID to /en/UUID format
    location ~ "^/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}" {
      return 301 /en$request_uri;
    }

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Host $host;
    proxy_set_header X-Forwarded-Port $server_port;
    proxy_set_header X-Forwarded-Proto $scheme;
  }

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/staging.alaricthatcherbooks.com/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/staging.alaricthatcherbooks.com/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
server {
    if ($host = staging.alaricthatcherbooks.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


  listen 80;
  server_name staging.alaricthatcherbooks.com;
    client_max_body_size 10m;
    return 404; # managed by Certbot


}